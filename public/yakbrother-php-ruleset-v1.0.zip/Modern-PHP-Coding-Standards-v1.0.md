# Modern PHP Coding Standards v1.0

**Purpose**: Comprehensive coding standards for professional PHP development, incorporating PSR-12, modern PHP 8.3+ features, security best practices, and community-tested patterns.

**Author**: Tim (@yakbrother)  
**Last Updated**: September 30, 2025  
**Target PHP Version**: 8.0+  
**Conformance**: PSR-1, PSR-12, Slevomat Coding Standard

---

## Philosophy: Why Standards Matter

PHP has evolved dramatically from its early days. Modern PHP (8.0+) is a mature, type-safe, performant language capable of building enterprise applications. However, this power requires discipline.

**Core Principle**: Code is read far more often than it's written. Standards reduce cognitive friction when switching between projects, enable better tooling, and prevent entire classes of bugs.

### The Three Goals

**1. Consistency** - Code should look like it was written by one person, regardless of team size.

**2. Safety** - Use the type system and modern features to prevent runtime errors.

**3. Maintainability** - Future developers (including yourself) should understand code intent quickly.

---

## Decision Framework

### Choosing Between Patterns

```
Need to store data without behavior?
├─ YES → Use DTO with readonly properties + constructor promotion
└─ NO → Need shared behavior across classes?
    ├─ YES → Can behavior be extracted to separate object?
        ├─ YES → Use Composition (inject dependency)
        └─ NO → Use Inheritance (extends) cautiously
    └─ NO → Use standard class with methods
```

### When to Use Modern PHP Features

```
Have optional parameters?
├─ 3+ parameters → Use named arguments
└─ 1-2 parameters → Positional arguments OK

Need to enforce immutability?
├─ Simple data object → readonly properties
└─ Entire class immutable → readonly class

Branching logic?
├─ Simple true/false assignment → ternary: $x = $condition ? 'yes' : 'no'
├─ Mapping values (status → color) → match expression
├─ 2-3 conditions, multiple statements each → if/elseif/else
└─ Complex nested logic (3+ levels) → extract to method with early returns
```

---

## Foundational Rules (PSR-1 & PSR-12)

### File Structure

**Encoding and Tags**:
```php
<?php

declare(strict_types=1);

// All PHP files MUST:
// - Use UTF-8 encoding without BOM
// - Start with <?php tag
// - Have declare(strict_types=1) as first statement
// - Omit closing ?> tag in pure PHP files
// - End with single LF (linefeed)
```

**Why strict_types?** Prevents silent type coercion that causes bugs:
```php
// WITHOUT strict_types
function add(int $a, int $b): int {
    return $a + $b;
}

echo add("5", "10"); // Returns 15 (strings coerced to ints!)

// WITH strict_types
declare(strict_types=1);

function add(int $a, int $b): int {
    return $a + $b;
}

echo add("5", "10"); // TypeError thrown immediately
```

### Naming Conventions

```php
// Classes, Interfaces, Traits: PascalCase
class UserRepository {}
interface PaymentGateway {}
trait Timestampable {}

// Methods: camelCase
public function findUserById(int $id): ?User {}

// Properties: camelCase
private string $userName;

// Constants: UPPER_SNAKE_CASE
public const MAX_LOGIN_ATTEMPTS = 5;

// Avoid redundant suffixes
interface Order {}           // Good
interface OrderInterface {}  // Bad - redundant
```

**Why avoid Interface suffix?** Modern IDEs show type information. The name should describe purpose, not implementation detail.

### Formatting Basics

**Indentation**: 4 spaces (never tabs)

**Line Length**: 
- Soft limit: 120 characters
- Hard limit: None (but split long lines)
- Target: 80 characters or less

**Why 80 characters?** Allows side-by-side code comparison and works on all displays.

```php
// Good - readable within 80 chars
public function createUser(
    string $email,
    string $password
): User {
    return new User($email, $password);
}

// Bad - hard to read, need horizontal scrolling
public function createUserWithEmailAddressAndHashedPasswordAndOptionalProfilePicture(string $emailAddress, string $hashedPassword, ?string $profilePictureUrl = null): User {}
```

### Namespace and Use Statements

```php
<?php

declare(strict_types=1);

namespace App\Domain\User;

use App\Domain\User\ValueObject\Email;
use App\Domain\User\ValueObject\UserId;
use App\Infrastructure\Persistence\UserRepository;
use Psr\Log\LoggerInterface;

// Rules:
// 1. namespace immediately after declare(strict_types=1)
// 2. One blank line after namespace
// 3. use statements grouped and alphabetically sorted
// 4. One blank line after use statements
// 5. No leading backslash in use statements
```

**Grouping use statements**:
```php
// Group by root namespace, separate with blank line
use App\Domain\Order\Order;
use App\Domain\Order\OrderItem;

use App\Infrastructure\Email\Mailer;
use App\Infrastructure\Payment\Gateway;

use Psr\Log\LoggerInterface;
```

---

## Modern PHP Syntax (PHP 8.0+)

### Type System: Use It Everywhere

**The Rule**: Every property, parameter, and return value should have a type declaration unless impossible.

```php
// Excellent - fully typed
final readonly class CreateUserCommand
{
    public function __construct(
        public string $email,
        public string $password,
        public ?string $name = null,
    ) {}
}

// Bad - no types
class CreateUserCommand
{
    public function __construct(
        public $email,
        public $password,
        public $name = null,
    ) {}
}
```

**Type Hierarchy** (from specific to general):
```php
// Use most specific type possible
function process(Invoice $invoice): Money {} // Best - specific type

function process(object $item): Money {}     // OK - generic object

function process(mixed $item): Money {}      // Last resort - anything
```

**Union Types** (PHP 8.0+):
```php
function formatId(int|string $id): string 
{
    return (string) $id;
}

// Can accept either type
formatId(123);     // OK
formatId("ABC");   // OK
formatId(12.5);    // TypeError
```

**Intersection Types** (PHP 8.1+):
```php
interface Identifiable {
    public function getId(): int;
}

interface Timestamped {
    public function getCreatedAt(): DateTimeImmutable;
}

// Object must implement BOTH interfaces
function logEntity(Identifiable&Timestamped $entity): void 
{
    echo "ID: {$entity->getId()}, Created: {$entity->getCreatedAt()->format('Y-m-d')}";
}
```

**Nullable Types**:
```php
// Two equivalent syntaxes
function find(int $id): ?User {}     // Preferred - shorter
function find(int $id): User|null {} // Also valid

// Nullable parameter with null default
function greet(?string $name = null): string 
{
    return $name ?? 'Guest';
}
```

### Constructor Property Promotion (PHP 8.0+)

Eliminates boilerplate for simple data objects.

```php
// Old way - verbose
class User 
{
    private string $email;
    private string $name;
    
    public function __construct(string $email, string $name) 
    {
        $this->email = $email;
        $this->name = $name;
    }
    
    public function getEmail(): string 
    {
        return $this->email;
    }
}

// Modern way - concise
final readonly class User 
{
    public function __construct(
        public string $email,
        public string $name,
    ) {}
}
```

**When to use**: DTOs, Value Objects, Commands, Events - any class that primarily holds data.

**When NOT to use**: Classes with complex initialization logic or behavior-heavy objects.

### Readonly Properties and Classes (PHP 8.1+)

Create immutable objects that can't be accidentally modified.

```php
// Readonly property
class Order 
{
    public function __construct(
        public readonly OrderId $id,
        public readonly Money $total,
    ) {}
    
    // This would cause an error:
    // $this->total = new Money(100); // Error: Cannot modify readonly property
}

// Readonly class (PHP 8.2+)
readonly class CreateOrderCommand 
{
    public function __construct(
        public array $items,
        public string $customerId,
    ) {}
    // All properties automatically readonly
}
```

**Why immutability?** Prevents entire class of bugs from unexpected mutations. Makes code easier to reason about.

### Match Expression (PHP 8.0+)

Stricter, more concise alternative to switch.

```php
// switch - verbose, easy to forget break
switch ($status) {
    case 'pending':
        $color = 'yellow';
        break;
    case 'approved':
        $color = 'green';
        break;
    case 'rejected':
        $color = 'red';
        break;
    default:
        $color = 'gray';
}

// match - concise, returns value, no fallthrough
$color = match($status) {
    'pending' => 'yellow',
    'approved' => 'green',
    'rejected' => 'red',
    default => 'gray',
};
```

**Key differences**:
- `match` returns value, `switch` executes statements
- `match` is strict (===), `switch` is loose (==)
- `match` requires exhaustive handling (use `default`)
- `match` has no fallthrough (no `break` needed)

**Complex match patterns**:
```php
$message = match(true) {
    $age < 18 => 'Minor',
    $age >= 18 && $age < 65 => 'Adult',
    $age >= 65 => 'Senior',
};

// Multiple values, same result
$httpMethod = match($method) {
    'GET', 'HEAD' => 'safe',
    'POST', 'PUT', 'PATCH', 'DELETE' => 'unsafe',
    default => throw new InvalidArgumentException("Unknown method: $method"),
};
```

### Named Arguments (PHP 8.0+)

Make function calls self-documenting and allow skipping optional parameters.

```php
// Positional - hard to understand
createUser('john@example.com', 'secret', null, true, false, 30);

// Named - self-documenting
createUser(
    email: 'john@example.com',
    password: 'secret',
    emailVerified: true,
    age: 30,
);

// Can skip optional parameters in any order
createUser(
    email: 'john@example.com',
    password: 'secret',
    age: 30, // Skipped name, emailVerified, newsletter
);
```

**When to use**:
- Functions with 3+ parameters
- Functions with many optional parameters
- Improved clarity is worth slightly more verbose code

**When NOT to use**:
- Simple, obvious functions: `max(1, 2)` not `max(value1: 1, value2: 2)`
- Performance-critical tight loops (tiny overhead)

### Short Closures (PHP 7.4+)

```php
// Old closure
$ids = array_map(function ($user) {
    return $user->id;
}, $users);

// Short closure (arrow function)
$ids = array_map(fn($user) => $user->id, $users);

// Automatically captures variables from parent scope
$multiplier = 10;
$result = array_map(fn($n) => $n * $multiplier, [1, 2, 3]);
// No need for 'use ($multiplier)'
```

**When to use**: One-line transformations, callbacks.

**When NOT to use**: Multi-line logic (use regular closure).

### Enums (PHP 8.1+)

Type-safe, named constants.

```php
// Basic enum
enum Status 
{
    case Pending;
    case Approved;
    case Rejected;
}

function updateOrder(Order $order, Status $status): void 
{
    // Type-safe - can only pass Status enum values
    $order->setStatus($status);
}

updateOrder($order, Status::Approved); // OK
updateOrder($order, 'approved');       // TypeError

// Backed enum (with values)
enum Status: string 
{
    case Pending = 'pending';
    case Approved = 'approved';
    case Rejected = 'rejected';
    
    public function color(): string 
    {
        return match($this) {
            self::Pending => 'yellow',
            self::Approved => 'green',
            self::Rejected => 'red',
        };
    }
}

echo Status::Approved->value;  // 'approved'
echo Status::Approved->color(); // 'green'
```

**Use enums instead of**:
- Class constants for fixed sets
- String/int constants
- Boolean flags (consider enum instead)

---

## Object-Oriented Design

### Composition Over Inheritance

**The Problem with Deep Inheritance**:
```php
// Bad - rigid inheritance hierarchy
class Vehicle {}
class Car extends Vehicle {}
class SportsCar extends Car {}
class Ferrari extends SportsCar {}
// Now what if you need ElectricFerrari? Multiple inheritance isn't allowed!
```

**Solution - Composition**:
```php
// Good - flexible composition
interface Engine {
    public function start(): void;
}

class ElectricEngine implements Engine {
    public function start(): void { /* ... */ }
}

class GasolineEngine implements Engine {
    public function start(): void { /* ... */ }
}

final class Car 
{
    public function __construct(
        private Engine $engine,
        private Transmission $transmission,
    ) {}
    
    public function start(): void 
    {
        $this->engine->start();
    }
}

// Easy to create any combination
$electricCar = new Car(new ElectricEngine(), new AutomaticTransmission());
$gasCar = new Car(new GasolineEngine(), new ManualTransmission());
```

**When inheritance IS appropriate**:
- Extending framework classes (Controller, Model)
- True "is-a" relationships where child is specialized version
- Shallow hierarchies (1-2 levels max)

### Declare Classes as Final by Default

```php
// Prefer this
final class UserService 
{
    // implementation
}

// Over this
class UserService  // Implicitly extendable
{
    // implementation
}
```

**Why?** Prevents fragile base class problem. If class needs to be extended later, remove `final` explicitly.

**Exceptions**: 
- Abstract classes (can't be final)
- Framework base classes designed for extension
- Library code explicitly designed as extensible API

### Small, Focused Classes

```php
// Bad - God Object
class User 
{
    public function save() {}
    public function sendEmail() {}
    public function generateReport() {}
    public function processPayment() {}
    // ... 50 more methods
}

// Good - Single Responsibility
final class User {} // Just data

final class UserRepository {
    public function save(User $user): void {}
}

final class UserNotifier {
    public function sendWelcomeEmail(User $user): void {}
}

final class UserReportGenerator {
    public function generate(User $user): Report {}
}
```

**Rule of thumb**: If class name contains "and" or "or", it probably does too much.

---

## Control Structures and Logic

### Early Returns

Reduce nesting, improve readability.

```php
// Bad - deep nesting
public function processOrder(Order $order): void 
{
    if ($order->isValid()) {
        if ($order->hasStock()) {
            if ($order->isPaid()) {
                // actual logic buried here
                $this->fulfill($order);
            } else {
                throw new UnpaidOrderException();
            }
        } else {
            throw new InsufficientStockException();
        }
    } else {
        throw new InvalidOrderException();
    }
}

// Good - early returns
public function processOrder(Order $order): void 
{
    if (!$order->isValid()) {
        throw new InvalidOrderException();
    }
    
    if (!$order->hasStock()) {
        throw new InsufficientStockException();
    }
    
    if (!$order->isPaid()) {
        throw new UnpaidOrderException();
    }
    
    // Happy path at same indentation level
    $this->fulfill($order);
}
```

### Avoid Yoda Conditions

Write comparisons in natural order.

```php
// Bad - Yoda condition (backwards)
if (null === $user) {}
if (5 === $count) {}

// Good - natural order
if ($user === null) {}
if ($count === 5) {}
```

**Why?** More readable. Modern IDEs prevent accidental assignment (`if ($user = null)`).

### Use Null Coalescing Operator

```php
// Bad - verbose ternary
$name = isset($_GET['name']) ? $_GET['name'] : 'Guest';

// Good - null coalescing
$name = $_GET['name'] ?? 'Guest';

// Chain multiple fallbacks
$name = $user->name ?? $defaultName ?? 'Guest';
```

### Ternary for Simple Assignments Only

```php
// Good - simple value selection
$status = $isActive ? 'Active' : 'Inactive';

// Bad - complex logic (use if/else or match)
$message = $user->isAdmin() && $user->hasPermission('delete') && !$user->isSuspended() 
    ? 'You can delete this' 
    : $user->isAdmin() 
        ? 'You are suspended' 
        : 'Insufficient permissions';

// Better - explicit if/else
if ($user->isAdmin() && $user->hasPermission('delete') && !$user->isSuspended()) {
    $message = 'You can delete this';
} elseif ($user->isAdmin()) {
    $message = 'You are suspended';
} else {
    $message = 'Insufficient permissions';
}

// Even better - extract to method
$message = $this->getDeletionMessage($user);
```

---

## Security Best Practices

### Never Trust User Input

**Input Validation**:
```php
// Bad - trusting input
$id = $_GET['id'];
$user = $db->query("SELECT * FROM users WHERE id = $id"); // SQL injection!

// Good - validate and sanitize
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if ($id === false || $id === null) {
    throw new InvalidArgumentException('Invalid ID');
}

// Better - use parameterized queries
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
```

### Always Use Prepared Statements

```php
// NEVER DO THIS - SQL injection vulnerability
$email = $_POST['email'];
$query = "SELECT * FROM users WHERE email = '$email'";
// Attacker can send: ' OR '1'='1

// Always use prepared statements
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);

// Or named parameters
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
$stmt->execute(['email' => $email]);
```

### Escape Output (XSS Prevention)

```php
// Bad - outputting user data directly
echo "<h1>Welcome {$user->name}</h1>"; 
// If name is: <script>alert('XSS')</script>

// Good - escape output
echo "<h1>Welcome " . htmlspecialchars($user->name, ENT_QUOTES, 'UTF-8') . "</h1>";

// In templates (using short echo tag)
<h1>Welcome <?= htmlspecialchars($user->name, ENT_QUOTES, 'UTF-8') ?></h1>

// Even better - use template engine with auto-escaping (Blade, Twig)
<h1>Welcome {{ $user->name }}</h1> <!-- Auto-escaped -->
```

### Password Hashing

```php
// NEVER store plain passwords or use md5/sha1
// Bad
$hash = md5($password); // Broken, easily cracked

// Good - use password_hash
$hash = password_hash($password, PASSWORD_ARGON2ID);

// Verify password
if (password_verify($inputPassword, $storedHash)) {
    // Correct password
}

// Check if hash needs rehashing (algorithm changed)
if (password_needs_rehash($storedHash, PASSWORD_ARGON2ID)) {
    $newHash = password_hash($password, PASSWORD_ARGON2ID);
    // Update database
}
```

### CSRF Protection

```php
// Generate token
session_start();
$token = bin2hex(random_bytes(32));
$_SESSION['csrf_token'] = $token;

// In form
echo '<input type="hidden" name="csrf_token" value="' . $token . '">';

// Verify token
if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    die('CSRF token validation failed');
}
```

### Avoid Dangerous Functions

**NEVER use these functions**:
```php
eval($code);           // Executes arbitrary PHP code
exec($command);        // Executes shell commands
system($command);      // Executes shell commands
extract($_POST);       // Creates variables from array keys (name collision)
$$variable;            // Variable variables (hard to track)
```

If you must execute shell commands, use escapeshellarg():
```php
// Bad
exec("rm -rf " . $_GET['dir']); // Command injection!

// Better (but still avoid if possible)
$dir = escapeshellarg($_GET['dir']);
exec("rm -rf $dir");
```

---

## Error Handling

### Use Typed Exceptions

```php
// Bad - generic exceptions
throw new Exception('User not found');
throw new Exception('Invalid email');
throw new Exception('Payment failed');

// Good - specific exception types
throw new UserNotFoundException($userId);
throw new InvalidEmailException($email);
throw new PaymentFailedException($transactionId, $reason);
```

**Define domain exceptions**:
```php
namespace App\Domain\User\Exception;

final class UserNotFoundException extends \DomainException 
{
    public function __construct(
        public readonly int $userId,
    ) {
        parent::__construct("User not found: {$userId}");
    }
}
```

### Don't Catch Generic Exceptions

```php
// Bad - catches everything, including programming errors
try {
    $user = $this->repository->find($id);
    $this->processUser($user);
} catch (\Exception $e) {
    // Silently catches typos, logic errors, everything
    return null;
}

// Good - catch specific exceptions
try {
    $user = $this->repository->find($id);
    $this->processUser($user);
} catch (UserNotFoundException $e) {
    $this->logger->info("User {$id} not found");
    return null;
} catch (DatabaseException $e) {
    $this->logger->error("Database error: " . $e->getMessage());
    throw $e; // Re-throw infrastructure errors
}
```

### Never Return Null for Errors

```php
// Bad - null overload
public function findUser(int $id): ?User 
{
    try {
        return $this->repository->find($id);
    } catch (DatabaseException $e) {
        return null; // Error or not found?
    }
}

// Good - distinguish errors from "not found"
public function findUser(int $id): ?User 
{
    return $this->repository->find($id); // Returns null if not found
    // Let exceptions bubble up for real errors
}

// Or use explicit exception
public function getUser(int $id): User 
{
    $user = $this->repository->find($id);
    
    if ($user === null) {
        throw new UserNotFoundException($id);
    }
    
    return $user;
}
```

---

## Testing Guidelines

### Test Structure

```php
use PHPUnit\Framework\TestCase;

final class UserServiceTest extends TestCase 
{
    /** @test */
    public function it_creates_user_with_valid_data(): void 
    {
        // Arrange
        $service = new UserService($this->createMock(UserRepository::class));
        $email = 'test@example.com';
        $password = 'SecurePass123';
        
        // Act
        $user = $service->createUser($email, $password);
        
        // Assert
        $this->assertInstanceOf(User::class, $user);
        $this->assertEquals($email, $user->email);
    }
    
    /** @test */
    public function it_throws_exception_for_invalid_email(): void 
    {
        $service = new UserService($this->createMock(UserRepository::class));
        
        $this->expectException(InvalidEmailException::class);
        
        $service->createUser('invalid-email', 'password');
    }
}
```

**Test naming**: Use descriptive names that explain behavior, not implementation.

```php
// Good
public function it_sends_welcome_email_after_registration(): void {}
public function it_prevents_duplicate_email_addresses(): void {}

// Bad
public function testMethod1(): void {}
public function testCreate(): void {}
```

### What to Test

**DO test**:
- Public API behavior
- Edge cases and boundary conditions
- Error handling paths
- Business logic

**DON'T test**:
- Private methods (test through public API)
- Framework code
- Third-party libraries
- Trivial getters/setters

---

## Code Organization

### Directory Structure

```
src/
├── Domain/              # Business logic, entities, value objects
│   ├── User/
│   │   ├── User.php
│   │   ├── UserRepository.php (interface)
│   │   ├── ValueObject/
│   │   │   ├── Email.php
│   │   │   └── UserId.php
│   │   └── Exception/
│   │       └── UserNotFoundException.php
│   └── Order/
│       ├── Order.php
│       └── OrderItem.php
├── Application/         # Use cases, commands, handlers
│   ├── CreateUser/
│   │   ├── CreateUserCommand.php
│   │   └── CreateUserHandler.php
│   └── ProcessOrder/
│       ├── ProcessOrderCommand.php
│       └── ProcessOrderHandler.php
└── Infrastructure/      # External concerns (DB, email, API)
    ├── Persistence/
    │   └── DoctrineUserRepository.php
    └── Email/
        └── SmtpMailer.php
```

**Principle**: Dependencies point inward. Domain has no external dependencies.

### File Per Class

```php
// Each class in its own file
// src/Domain/User/User.php
namespace App\Domain\User;

final class User {}

// src/Domain/User/UserRepository.php
namespace App\Domain\User;

interface UserRepository {}
```

---

## Performance Considerations

### Opcache

Always enable opcache in production:
```ini
; php.ini
opcache.enable=1
opcache.memory_consumption=256
opcache.max_accelerated_files=20000
opcache.validate_timestamps=0  ; Don't check file changes in production
```

### Avoid N+1 Queries

```php
// Bad - N+1 query problem
$users = User::all();
foreach ($users as $user) {
    echo $user->posts->count(); // Separate query for each user!
}

// Good - eager loading
$users = User::with('posts')->get();
foreach ($users as $user) {
    echo $user->posts->count(); // Already loaded
}
```

### Cache Expensive Operations

```php
// Bad - recalculate every time
public function getMonthlyRevenue(): float 
{
    return $this->orders
        ->where('created_at', '>=', now()->startOfMonth())
        ->sum('total');
}

// Good - cache result
public function getMonthlyRevenue(): float 
{
    return Cache::remember('monthly_revenue', 3600, function() {
        return $this->orders
            ->where('created_at', '>=', now()->startOfMonth())
            ->sum('total');
    });
}
```

---

## Slevomat Coding Standard (Selected Rules)

These advanced checks improve code quality beyond PSR-12.

### Functional Safety

**Declare Strict Types** (Mandatory):
```php
<?php

declare(strict_types=1); // Must be first statement
```

**Nullable Type for Null Default**:
```php
// Bad
public function greet(string $name = null): string {}

// Good
public function greet(?string $name = null): string {}
```

**Unused Imports**:
```php
// Bad
use App\User;
use App\Order; // Never used
use App\Product;

// Good - remove unused
use App\User;
use App\Product;
```

**Alphabetically Sorted Imports**:
```php
// Bad
use Symfony\Component\HttpFoundation\Response;
use App\Service\UserService;
use Psr\Log\LoggerInterface;

// Good
use App\Service\UserService;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\Response;
```

### Cleaning Dead Code

**Unused Private Methods**:
```php
// Bad
final class UserService 
{
    public function createUser(): void {}
    
    private function helperMethod(): void {} // Never called - remove it!
}
```

**Unused Parameters**:
```php
// Bad
public function process(Order $order, User $user): void 
{
    // $user is never used
    $this->fulfill($order);
}

// Good - remove unused parameter
public function process(Order $order): void 
{
    $this->fulfill($order);
}
```

**Useless Parentheses**:
```php
// Bad
return ($value);
if (($x === 5)) {}

// Good
return $value;
if ($x === 5) {}
```

---

## Common Anti-Patterns to Avoid

### God Objects

```php
// Anti-pattern
class Application 
{
    public function handleRequest() {}
    public function connectToDatabase() {}
    public function sendEmail() {}
    public function processPayment() {}
    public function generateReport() {}
    // ... 100 more methods
}

// Solution: Split responsibilities
class RequestHandler {}
class DatabaseConnection {}
class EmailService {}
class PaymentProcessor {}
class ReportGenerator {}
```

### Magic Numbers

```php
// Bad
if ($status === 1) {}
if ($userType === 3) {}

// Good - named constants
private const STATUS_ACTIVE = 1;
private const USER_TYPE_ADMIN = 3;

if ($status === self::STATUS_ACTIVE) {}
if ($userType === self::USER_TYPE_ADMIN) {}

// Even better - enums
enum Status: int {
    case Active = 1;
    case Inactive = 2;
}

if ($status === Status::Active) {}
```

### Boolean Parameters

```php
// Bad - what does true mean?
$user->update(true);
$service->process($data, false, true);

// Good - explicit
$user->update(sendEmail: true);
// Or even better - separate methods
$user->updateAndNotify();
$user->updateSilently();
```

### Returning Collections as Arrays

```php
// Bad - no type safety
public function getUsers(): array {} // Array of what?

// Good - typed iterable
/** @return User[] */
public function getUsers(): array {} // Better

// Best - use Collection class
public function getUsers(): Collection {} // Type-safe, has methods
```

---

## Tooling

### PHP_CodeSniffer

Check code against standards:
```bash
composer require --dev squizlabs/php_codesniffer

# Check code
vendor/bin/phpcs --standard=PSR12 src/

# Auto-fix violations
vendor/bin/phpcbf --standard=PSR12 src/
```

### PHPStan

Static analysis for type safety:
```bash
composer require --dev phpstan/phpstan

# Analyze code (level 0-9, 9 is strictest)
vendor/bin/phpstan analyse --level=8 src/
```

### Psalm

Alternative static analyzer:
```bash
composer require --dev vimeo/psalm

# Initialize
vendor/bin/psalm --init

# Analyze
vendor/bin/psalm
```

### PHP-CS-Fixer

Automatic code formatting:
```bash
composer require --dev friendsofphp/php-cs-fixer

# Fix code style
vendor/bin/php-cs-fixer fix src/
```

---

## References and Further Reading

### Standards
- **PSR-1: Basic Coding Standard**: [php-fig.org/psr/psr-1](https://www.php-fig.org/psr/psr-1/)
- **PSR-12: Extended Coding Style**: [php-fig.org/psr/psr-12](https://www.php-fig.org/psr/psr-12/)
- **PSR-4: Autoloading Standard**: [php-fig.org/psr/psr-4](https://www.php-fig.org/psr/psr-4/)

### Books and Resources
- **Front Line PHP** by Brent Roose: [front-line-php.com](https://front-line-php.com) - Modern PHP 8.3+ practices
- **PHP: The Right Way**: [phptherightway.com](https://phptherightway.com) - Best practices guide

### Tools and Standards
- **Slevomat Coding Standard**: [github.com/slevomat/coding-standard](https://github.com/slevomat/coding-standard) - Advanced PHP_CodeSniffer rules
- **PHPStan**: [phpstan.org](https://phpstan.org) - Static analysis tool
- **Psalm**: [psalm.dev](https://psalm.dev) - Static analysis and type checker

### Security
- **OWASP PHP Security Cheat Sheet**: [cheatsheetseries.owasp.org](https://cheatsheetseries.owasp.org/cheatsheets/PHP_Configuration_Cheat_Sheet.html)
- **Paragon Initiative - PHP Security**: [paragonie.com/blog](https://paragonie.com/blog)

---

**Version History**:
- v1.0 (2025-09-30): Initial comprehensive ruleset

**License**: CC BY-SA 4.0 - Use freely, attribute, share improvements

---

*This document lives at stack.yakbrother.dev and is continuously refined based on real-world usage.*
