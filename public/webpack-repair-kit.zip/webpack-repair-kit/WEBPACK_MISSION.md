# WEBPACK EMERGENCY REPAIR MISSION

## CRITICAL FACTS - NEVER FORGET THESE

### Environment
- LOCAL DEV: manage.intracta.com = localhost alias (NOT PRODUCTION)
- Test URL: http://manage.intracta.com (default port)
- This is LOCAL TESTING ONLY

### The Problem
- Server now blocks CDN requests (security policy change)
- Site is currently BROKEN - nothing loads
- ALL external libraries must be bundled locally via webpack
- Webpack config exists but has NEVER worked correctly

### Success Criteria (ALL MUST PASS)
1. Webpack builds without errors (outputs to dist/)
2. Page loads at http://manage.intracta.com
3. Browser console shows ZERO errors
4. All interactive features work:
   - Modal opens for creating new meeting
   - Datepicker appears when clicked
   - Timepicker functions
   - SweetAlert displays
5. Playwright tests pass (see tests/smoke.spec.js)

### Mission Rules
1. After EVERY change, run full test cycle
2. If tests fail, you MUST fix before moving to next change
3. Document what order bundles load in LOAD_ORDER.md
4. Never claim success without Playwright confirmation

## Libraries That Must Load (CRITICAL)
- jQuery (required by everything else)
- Bootstrap (UI framework)
- SweetAlert (Swal) (alerts/confirmations)
- Timepicker (time selection)
- Datepicker (date selection)

## Test Protocol (MANDATORY AFTER EVERY CHANGE)

1. Clean build:
   ```bash
   rm -rf dist/
   npm run build
   ```

2. Start dev server:
   ```bash
   npm run dev
   ```

3. Run Playwright tests:
   ```bash
   npm run test:browser
   ```

4. Check browser console at http://manage.intracta.com
   - Must show ZERO errors
   - Must show ZERO 404s
   - Must show all libraries loaded

## DO NOT PROCEED TO NEXT STEP UNTIL CURRENT STEP PASSES ALL TESTS

## Bundle Load Order (CRITICAL)
Document the correct order in LOAD_ORDER.md as you fix it:
1. jQuery MUST load first (everything depends on it)
2. Bootstrap (depends on jQuery)
3. Datepicker (depends on jQuery)
4. Timepicker (depends on jQuery)
5. SweetAlert (standalone but may use jQuery)
6. Application code (depends on all above)
