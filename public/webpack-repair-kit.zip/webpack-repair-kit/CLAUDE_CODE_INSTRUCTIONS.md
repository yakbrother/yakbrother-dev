# CLAUDE CODE INSTRUCTION SET

You are fixing a BLOCKING PRODUCTION ISSUE. The server blocks CDN requests, so webpack MUST work.

## Non-Negotiable Rules:

1. **ENVIRONMENT**: manage.intracta.com is LOCAL (localhost alias), NOT production
2. **TESTING**: After EVERY change, run: `npm run build && npm run test:browser`
3. **SUCCESS**: Only claim completion when Playwright tests pass with ZERO errors
4. **NO SHORTCUTS**: If tests fail, you MUST fix before changing anything else
5. **OUTPUT**: All bundles build to dist/ directory

## Your Workflow:

### Step 1: Initial Assessment
1. Read WEBPACK_MISSION.md completely
2. Examine current webpack.config.js
3. List all entry points and outputs
4. Identify current bundle order
5. Document findings in LOAD_ORDER.md

### Step 2: Fix One Thing At A Time
1. Make ONE change to webpack config
2. Run: `rm -rf dist/ && npm run build`
3. Check build output for errors
4. If build fails: fix it before proceeding
5. If build succeeds: run `npm run test:browser`
6. If tests fail: fix it before proceeding
7. Document what you changed and why

### Step 3: Iterate Until All Tests Pass
- Keep making small changes
- Test after each change
- Document your progress
- DO NOT move to the next issue until current tests pass

## Critical Library Load Order (MUST FOLLOW):

1. **jQuery** - MUST load first (everything depends on it)
2. **Bootstrap** - depends on jQuery
3. **Datepicker** - depends on jQuery  
4. **Timepicker** - depends on jQuery
5. **SweetAlert** - can load anytime but after jQuery is safer
6. **Application code** - MUST load last

Your webpack config must ensure this order in the bundles.

## Before You Say "It Works":

Run this checklist:

```bash
# Clean build
rm -rf dist/
npm run build
# Should complete with NO errors

# Start server (if needed)
npm run dev &

# Run tests
npm run test:browser
# ALL tests must pass

# Manual check
# Open http://manage.intracta.com in browser
# Console should show ZERO errors
# Click "New Meeting" - modal should open
# Click date input - datepicker should appear
# Click time input - timepicker should appear
```

- [ ] npm run build completes with no errors
- [ ] dist/ directory contains bundles
- [ ] npm run test:browser passes ALL 6 tests
- [ ] Browser console at manage.intracta.com shows zero errors
- [ ] Modal opens when "New Meeting" clicked
- [ ] Datepicker appears when date field clicked
- [ ] Timepicker appears when time field clicked

## Common Webpack Issues To Check:

1. **Wrong entry points** - Are all necessary files included?
2. **Missing externals** - Are libraries trying to load from CDN still?
3. **Wrong output paths** - Does HTML point to where bundles actually are?
4. **Module resolution** - Can webpack find all the node_modules?
5. **Load order** - Are dependencies loaded before code that uses them?
6. **Plugin conflicts** - Are webpack plugins fighting each other?

## If You Get Stuck:

1. Document exactly what error you're seeing
2. Show the relevant webpack config section
3. Show the browser console error
4. Show the build output
5. Ask Tim for clarification on specific selectors or paths

## Remember:

- manage.intracta.com = LOCAL, not production
- Test after EVERY change
- No shortcuts
- Document everything in LOAD_ORDER.md

Read WEBPACK_MISSION.md now and confirm you understand the mission before making ANY changes.
