// tests/smoke.spec.js
const { test, expect } = require('@playwright/test');

const BASE_URL = 'http://manage.intracta.com';

test.describe('Webpack Bundle Loading - Critical Path', () => {
  
  test('page loads without console errors', async ({ page }) => {
    const errors = [];
    const warnings = [];
    
    page.on('console', msg => {
      if (msg.type() === 'error') {
        errors.push(msg.text());
      }
      if (msg.type() === 'warning') {
        warnings.push(msg.text());
      }
    });
    
    page.on('pageerror', error => {
      errors.push(error.message);
    });

    await page.goto(BASE_URL);
    
    // Wait for page to fully load
    await page.waitForLoadState('networkidle');
    
    // Log warnings for visibility but don't fail on them
    if (warnings.length > 0) {
      console.log('Warnings detected:', warnings);
    }
    
    // MUST have zero errors
    expect(errors, `Console errors detected: ${errors.join(', ')}`).toEqual([]);
  });

  test('all required libraries are loaded', async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    
    // Check jQuery loaded (CRITICAL - everything depends on this)
    const hasJQuery = await page.evaluate(() => {
      return typeof window.jQuery !== 'undefined' && typeof window.$ !== 'undefined';
    });
    expect(hasJQuery, 'jQuery must be loaded').toBeTruthy();
    
    // Check Bootstrap loaded
    const hasBootstrap = await page.evaluate(() => {
      return typeof window.bootstrap !== 'undefined' || 
             (typeof window.$ !== 'undefined' && typeof window.$.fn.modal !== 'undefined');
    });
    expect(hasBootstrap, 'Bootstrap must be loaded').toBeTruthy();
    
    // Check SweetAlert loaded
    const hasSwal = await page.evaluate(() => {
      return typeof window.Swal !== 'undefined' || typeof window.swal !== 'undefined';
    });
    expect(hasSwal, 'SweetAlert must be loaded').toBeTruthy();
    
    // Check Datepicker available
    const hasDatepicker = await page.evaluate(() => {
      return typeof window.$ !== 'undefined' && 
             (typeof window.$.fn.datepicker !== 'undefined' || 
              typeof window.$.fn.daterangepicker !== 'undefined');
    });
    expect(hasDatepicker, 'Datepicker must be loaded').toBeTruthy();
    
    // Check Timepicker available
    const hasTimepicker = await page.evaluate(() => {
      return typeof window.$ !== 'undefined' && 
             typeof window.$.fn.timepicker !== 'undefined';
    });
    expect(hasTimepicker, 'Timepicker must be loaded').toBeTruthy();
  });

  test('no 404 errors for bundle files', async ({ page }) => {
    const failed = [];
    
    page.on('response', response => {
      if (response.status() === 404) {
        const url = response.url();
        if (url.includes('.js') || url.includes('.css')) {
          failed.push(url);
        }
      }
    });
    
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    
    expect(failed, `404 errors for resources: ${failed.join(', ')}`).toEqual([]);
  });

  test('modal opens for creating new meeting', async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    
    // Find and click the button/link to create new meeting
    // Adjust selector based on your actual HTML
    const newMeetingButton = page.locator('button:has-text("New Meeting"), a:has-text("New Meeting"), [data-action="new-meeting"]').first();
    
    // Check if button exists
    await expect(newMeetingButton, 'New meeting button should exist').toBeVisible({ timeout: 5000 });
    
    // Click it
    await newMeetingButton.click();
    
    // Wait for modal to appear - adjust selector based on your modal structure
    const modal = page.locator('.modal.show, [role="dialog"]:visible, #newMeetingModal.show').first();
    await expect(modal, 'Modal should open after clicking new meeting').toBeVisible({ timeout: 3000 });
  });

  test('datepicker appears when input is clicked', async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    
    // Open the new meeting modal first (if datepicker is inside it)
    const newMeetingButton = page.locator('button:has-text("New Meeting"), a:has-text("New Meeting"), [data-action="new-meeting"]').first();
    
    if (await newMeetingButton.isVisible()) {
      await newMeetingButton.click();
      await page.waitForTimeout(500); // Give modal time to animate
    }
    
    // Find date input field - adjust selector based on your HTML
    const dateInput = page.locator('input[type="date"], input.datepicker, [data-datepicker]').first();
    
    await expect(dateInput, 'Date input should exist').toBeVisible({ timeout: 5000 });
    
    // Click the date input
    await dateInput.click();
    
    // Wait for datepicker UI to appear - adjust selector based on your datepicker library
    const datepickerUI = page.locator('.datepicker, .daterangepicker, .ui-datepicker').first();
    await expect(datepickerUI, 'Datepicker UI should appear').toBeVisible({ timeout: 3000 });
  });

  test('timepicker functions on time input', async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    
    // Open the new meeting modal first (if timepicker is inside it)
    const newMeetingButton = page.locator('button:has-text("New Meeting"), a:has-text("New Meeting"), [data-action="new-meeting"]').first();
    
    if (await newMeetingButton.isVisible()) {
      await newMeetingButton.click();
      await page.waitForTimeout(500);
    }
    
    // Find time input field - adjust selector based on your HTML
    const timeInput = page.locator('input[type="time"], input.timepicker, [data-timepicker]').first();
    
    await expect(timeInput, 'Time input should exist').toBeVisible({ timeout: 5000 });
    
    // Click the time input
    await timeInput.click();
    
    // Wait for timepicker UI to appear - adjust selector based on your timepicker library
    const timepickerUI = page.locator('.timepicker, .ui-timepicker-wrapper, .bootstrap-timepicker-widget').first();
    await expect(timepickerUI, 'Timepicker UI should appear').toBeVisible({ timeout: 3000 });
  });
});
