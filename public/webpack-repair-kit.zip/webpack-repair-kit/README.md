# Webpack Emergency Repair Kit

## What This Is

This is a complete instruction set for Claude Code to fix your broken webpack configuration that's preventing your site from loading after CDN blocking.

## The Problem

- Server now blocks CDN requests
- Site can't load jQuery, Bootstrap, SweetAlert, datepickers, timepickers
- Webpack exists but never worked correctly
- Site is currently DOWN

## The Solution

These files provide Claude Code with:
1. Clear mission parameters
2. Automated testing via Playwright
3. Success criteria that must be met
4. Step-by-step workflow

## Setup Instructions

### 1. Install Dependencies

```bash
# Install Playwright for testing
npm install -D @playwright/test

# Install Playwright browsers
npx playwright install

# Install missing webpack dependencies if needed
npm install -D webpack webpack-cli webpack-dev-server
```

### 2. Update Your package.json

Add these scripts if not present:

```json
"scripts": {
  "build": "webpack --mode production",
  "dev": "webpack serve --mode development",
  "test:browser": "playwright test"
}
```

### 3. Place Files In Your Project

- `WEBPACK_MISSION.md` → project root
- `CLAUDE_CODE_INSTRUCTIONS.md` → project root
- `LOAD_ORDER.md` → project root
- `tests/smoke.spec.js` → create tests/ folder if needed

### 4. Start Claude Code

1. Open a NEW Claude Code conversation
2. Paste the contents of `CLAUDE_CODE_INSTRUCTIONS.md`
3. Let it read `WEBPACK_MISSION.md`
4. Let it work through the problem step by step

### 5. Monitor Progress

Claude Code will:
- Test after every change
- Document progress in LOAD_ORDER.md
- Only claim success when ALL Playwright tests pass

## Success Criteria

✅ Webpack builds without errors
✅ All 6 Playwright tests pass
✅ Browser console shows zero errors at http://manage.intracta.com
✅ Modal opens for new meeting
✅ Datepicker appears when clicked
✅ Timepicker appears when clicked

## Important Notes

- **manage.intracta.com is LOCAL** (localhost alias), not production
- Tests MUST pass before moving to next change
- No shortcuts allowed
- Document everything

## Troubleshooting

If tests fail:
```bash
# Run tests in headed mode to see what's happening
npm run test:browser:headed

# Or debug mode for step-by-step
npm run test:browser:debug
```

## Files Included

1. **WEBPACK_MISSION.md** - Complete context about the problem
2. **CLAUDE_CODE_INSTRUCTIONS.md** - Step-by-step instructions for Claude Code
3. **tests/smoke.spec.js** - Playwright tests that MUST pass
4. **LOAD_ORDER.md** - Template for documenting bundle order
5. **package.json.example** - Example scripts setup
6. **README.md** - This file

## Next Steps After Success

Once webpack is working:
1. Review LOAD_ORDER.md to understand the final configuration
2. Test on actual devices/browsers
3. Update documentation for team
4. Plan migration of other pages if needed

Bon courage, mon ami! 🚀
